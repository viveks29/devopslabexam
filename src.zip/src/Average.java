class  Average
{
	public static void main(String[] args) 
	{
		if(args.length < 2)
		{
			System.out.println("Not enough arguments.");
			return;
		}
		double sum=0,avg=0;
		for(int i=0;i<args.length;i++)
		{
			sum+=Double.parseDouble(args[i]);
		}
		avg=(sum/args.length);
		System.out.println("average of " +args.length+"no : "+avg );
	}
}
