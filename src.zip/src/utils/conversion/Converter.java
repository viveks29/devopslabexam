package utils.conversion;
class Converter 
{
	static double poundConversion(double value)
	{
		System.out.println("Convert pounds to kg: ");
		return (value*0.4536);
	}
	static double tempConversion(double value)
	{
		System.out.println("Convert Celsius to Fahrenheit: ");
		return (value*(9/5)+32);
	}
	static String timeConversion(int value)
	{
		System.out.println("Convert Celsius to Fahrenheit: ");
		int hr, min, sec;
		while(value < 60)
		{
			min=min+value%60;
			value = value/60;
		}
		return ();
	}
	
	public static void main(String[] args) 
	{
		
	}
}
