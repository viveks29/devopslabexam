package com.app;
public class Calculator 
{
	private double firstNum, secondNum;
	public void setFirstNum(double num1)
		{
			firstNum = num1;
		}
	public void setSecondNum(double num2)
		{
			secondNum = num2;
		}
	double getFirstNum()
	{
		return firstNum;
	}
	double getSecondNum()
	{
		return secondNum;
	}
	public double add()
	{
		return firstNum+secondNum;
	}
	public double sub()
	{
		return firstNum-secondNum;
	}
	public double multiply()
	{
		return firstNum*secondNum;
	}
	public double divide()
	{
		if(secondNum == 0)
		{
			System.out.println("Divide by 0 error");
			return 0.0;
		}
		return firstNum/secondNum;
	}
}
