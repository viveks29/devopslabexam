package tester;
import java.util.Scanner;
class FoodMenu 
{
	public static void main(String[] args) 
	{
		int choice = 0, q;
		double finalBill=0;
		double bill=0;
		Scanner sc = new Scanner(System.in);
		while(choice < 11)
		{
			System.out.println("**********FOOD MENU**********");
			System.out.println("Enter 1 for Dosa, price = 40.");
			System.out.println("Enter 2 for Samosa, price = 15.");
			System.out.println("Enter 3 for Vada Paav, price = 10.");
			System.out.println("Enter 4 for Upma, price = 25.");
			System.out.println("Enter 5 for Bread Pattice, price = 30.");
			System.out.println("Enter 6 for Idli, price = 25.");
			System.out.println("Enter 7 for Burger, price = 90.");
			System.out.println("Enter 8 for Biryani, price = 150.");
			System.out.println("Enter 9 for Dhokla, price = 50.");
			System.out.println("Enter 10 for Pasta, price = 140.");
			System.out.println("Enter 11 to exit;");
			System.out.println("Enter your choice.");
			choice = sc.nextInt();
			switch(choice)
			{
				case 1: System.out.println("Enter quantity you want:");
						q = sc.nextInt();
						bill = 40*q;
						finalBill += bill;
						break;
				case 2: System.out.println("Enter quantity you want:");
						q = sc.nextInt();
						bill = 15*q;
						finalBill += bill;
						break;
				case 3: System.out.println("Enter quantity you want:");
						q = sc.nextInt();
						bill = 10*q;
						finalBill += bill;
						break;
				case 4: System.out.println("Enter quantity you want:");
						q = sc.nextInt();
						bill = 25*q;
						finalBill += bill;
						break;
				case 5: System.out.println("Enter quantity you want:");
						q = sc.nextInt();
						bill = 30*q;
						finalBill += bill;
						break;
				case 6: System.out.println("Enter quantity you want:");
						q = sc.nextInt();
						bill = 25*q;
						finalBill += bill;
						break;
				case 7: System.out.println("Enter quantity you want:");
						q = sc.nextInt();
						bill = 90*q;
						finalBill += bill;
						break;
				case 8: System.out.println("Enter quantity you want:");
						q = sc.nextInt();
						bill = 150*q;
						finalBill += bill;
						break;
				case 9: System.out.println("Enter quantity you want:");
						q = sc.nextInt();
						bill = 50*q;
						finalBill += bill;
						break;
				case 10: System.out.println("Enter quantity you want:");
						q = sc.nextInt();
						bill = 140*q;
						finalBill += bill;
						break;
			}
		}
		System.out.println("Total Bill: "+finalBill);
	}
}
