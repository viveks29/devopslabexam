package tester;
import com.app.*;
import java.util.Scanner;

class TestCalculator 
{
	public static void main(String[] args) 
	{
		int choice = 0;
		boolean exit=false;
		Calculator c = new Calculator();
		Scanner sc = new Scanner(System.in);
		while(!exit)
		{
			System.out.println("Enetr 1 to add 2 numbers:");
			System.out.println("Enetr 2 to sub 2 numbers:");
			System.out.println("Enetr 3 to multiply 2 numbers:");
			System.out.println("Enetr 4 to divide 2 numbers:");
			System.out.println("Enetr 5 to exit from menu:");
			System.out.print("Enter your choice: ");
			choice = sc.nextInt();
			System.out.println("Enetr two numbers:");
			c.setFirstNum(sc.nextDouble());
			c.setSecondNum(sc.nextDouble());
			switch(choice)
			{
				case 1: System.out.println(c.add());
						break;
				case 2: System.out.println(c.sub());
						break;
				case 3: System.out.println(c.multiply());
						break;
				case 4: System.out.println(c.divide());
						break;
				case 5:
						exit=true;
					break;
			}
		}

	}
}
 